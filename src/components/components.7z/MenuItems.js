export const MenuItems = [
    {
      title: 'Вся Одежда',
      path: '/Apparel',
      cName: 'dropdown-link'
    },
    {
      title: 'Футболки',
      path: '/#',
      // сверху путь к футболкам
      cName: 'dropdown-link'
    },
    {
      title: 'Худи & Джерси',
      path: '/Collectibles',
      cName: 'dropdown-link'
    },
    {
      title: 'Низ',
      path: '/Home',
      cName: 'dropdown-link'
    }
  ];

  export const MenuItemO = [
    {
      title: 'Все Аксессуары',
      path: '/Accessories',
      cName: 'dropdown-link'
    },
    {
      title: 'Нашивки',
      path: '/#',
      // сверху путь к футболкам
      cName: 'dropdown-link'
    },
    {
      title: 'Носки & Обувь',
      path: '/Collectibles',
      cName: 'dropdown-link'
    },
    {
      title: 'Броня котиков',
      path: '/Home',
      cName: 'dropdown-link'
    }
  ];

  export const MenuItemT = [
    {
      title: 'Все Коллекционнки',
      path: '/Collectibles',
      cName: 'dropdown-link'
    },
    {
      title: 'Статуэтки',
      path: '/#',
      // сверху путь к футболкам
      cName: 'dropdown-link'
    },
    {
      title: 'Фигурки & Игрушки',
      path: '/Collectibles',
      cName: 'dropdown-link'
    },
    {
      title: 'Принты',
      path: '/Home',
      cName: 'dropdown-link'
    }
  ];

  export const MenuItemF = [
    {
      title: 'Все Аксессуары',
      path: '/Accessories',
      cName: 'dropdown-link'
    },
    {
      title: 'Нашивки',
      path: '/#',
      // сверху путь к футболкам
      cName: 'dropdown-link'
    },
    {
      title: 'Носки & Обувь',
      path: '/Collectibles',
      cName: 'dropdown-link'
    },
    {
      title: 'Броня котиков',
      path: '/Home',
      cName: 'dropdown-link'
    }
  ];